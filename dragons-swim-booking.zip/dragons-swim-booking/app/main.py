from __future__ import annotations

import urllib.parse
from pathlib import Path

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from .config import Settings
from .db import (
    add_lesson,
    admin_summary,
    bookings_by_email,
    create_booking,
    get_booking,
    init_db,
    list_lessons,
    mark_paid,
)
from .models import BookingCreate, LessonCreate
from .payfast import (
    build_payment_fields,
    valid_payfast_ip,
    validate_with_payfast,
    verify_notification_signature,
)

BASE = Path(__file__).resolve().parents[1]
STATIC = BASE / "static"
settings = Settings.from_env()
init_db()

app = FastAPI(title="Dragons Swimming Club", version="1.0.0")
app.mount("/static", StaticFiles(directory=STATIC), name="static")


def require_admin(x_admin_key: str | None) -> None:
    if not x_admin_key or x_admin_key != settings.admin_key:
        raise HTTPException(status_code=401, detail="Invalid admin key")


@app.get("/api/health")
def health():
    return {"ok": True, "payment_mode": settings.payment_mode}


@app.get("/api/lessons")
def lessons(month: str | None = None):
    return {"lessons": list_lessons(month)}


@app.post("/api/bookings", status_code=201)
def bookings_create(payload: BookingCreate):
    try:
        return {"booking": create_booking(payload.model_dump(mode="json"))}
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.get("/api/bookings")
def bookings_list(email: str):
    return {"bookings": bookings_by_email(email)}


@app.post("/api/payments/payfast")
async def start_payment(request: Request):
    payload = await request.json()
    booking = get_booking(str(payload.get("booking_id", "")))
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    if settings.payment_mode == "demo":
        return {"mode": "demo", "booking": booking}
    try:
        fields = build_payment_fields(booking, settings)
    except ValueError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    return {"mode": settings.payment_mode, "action": settings.payfast_process_url, "fields": fields, "booking": booking}


@app.post("/api/payments/demo-complete")
async def demo_complete(request: Request):
    if settings.payment_mode != "demo":
        raise HTTPException(status_code=403, detail="Demo payment route is disabled")
    payload = await request.json()
    try:
        return {"booking": mark_paid(str(payload.get("booking_id", "")), "DEMO")}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.post("/api/payments/payfast/itn")
async def payfast_itn(request: Request):
    raw = (await request.body()).decode("utf-8")
    data = dict(urllib.parse.parse_qsl(raw, keep_blank_values=True))
    booking = get_booking(data.get("m_payment_id", ""))
    if not booking:
        return PlainTextResponse("Booking not found", status_code=404)
    if not verify_notification_signature(data, settings.payfast_passphrase):
        return PlainTextResponse("Invalid signature", status_code=400)
    try:
        paid_amount = float(data.get("amount_gross", "nan"))
    except ValueError:
        return PlainTextResponse("Invalid amount", status_code=400)
    if abs(paid_amount - float(booking["total"])) > 0.01:
        return PlainTextResponse("Amount mismatch", status_code=400)
    if not valid_payfast_ip(request.client.host if request.client else None):
        return PlainTextResponse("Invalid source", status_code=403)
    if not validate_with_payfast(data, settings.payfast_validate_url):
        return PlainTextResponse("Invalid Payfast data", status_code=400)
    if data.get("payment_status") == "COMPLETE":
        mark_paid(booking["id"], data.get("pf_payment_id", "PAYFAST"))
    return PlainTextResponse("OK", status_code=200)


@app.get("/api/admin/summary")
def admin_get_summary(x_admin_key: str | None = Header(default=None)):
    require_admin(x_admin_key)
    return admin_summary()


@app.post("/api/admin/lessons", status_code=201)
def admin_add_lesson(payload: LessonCreate, x_admin_key: str | None = Header(default=None)):
    require_admin(x_admin_key)
    try:
        return {"lesson": add_lesson(payload.model_dump())}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/payment/success")
def payment_success():
    return RedirectResponse(url="/#/bookings?payment=success", status_code=303)


@app.get("/payment/cancel")
def payment_cancel():
    return RedirectResponse(url="/#/bookings?payment=cancelled", status_code=303)


@app.get("/")
def index():
    return FileResponse(STATIC / "index.html")


@app.exception_handler(HTTPException)
async def http_error(_request: Request, exc: HTTPException):
    return JSONResponse(status_code=exc.status_code, content={"error": str(exc.detail)})
