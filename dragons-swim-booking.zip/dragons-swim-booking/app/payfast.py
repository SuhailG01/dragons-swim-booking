from __future__ import annotations

import hashlib
import ipaddress
import socket
import urllib.parse
import urllib.request
from collections.abc import Mapping

PAYFAST_NETWORKS = [
    ipaddress.ip_network("197.97.145.144/28"),
    ipaddress.ip_network("41.74.179.192/27"),
    ipaddress.ip_network("102.216.36.0/28"),
    ipaddress.ip_network("102.216.36.128/28"),
    ipaddress.ip_network("144.126.193.139/32"),
]
PAYFAST_HOSTS = ["www.payfast.co.za", "sandbox.payfast.co.za", "w1w.payfast.co.za", "w2w.payfast.co.za"]


def pf_encode(value: object) -> str:
    return urllib.parse.quote_plus(str(value).strip(), safe="")


def signature(data: Mapping[str, object], passphrase: str = "") -> str:
    pairs = []
    for key, value in data.items():
        if key == "signature" or value in {"", None}:
            continue
        pairs.append(f"{key}={pf_encode(value)}")
    if passphrase:
        pairs.append(f"passphrase={pf_encode(passphrase)}")
    return hashlib.md5("&".join(pairs).encode("utf-8")).hexdigest()


def build_payment_fields(booking: dict, settings) -> dict[str, str]:
    if not settings.payfast_merchant_id or not settings.payfast_merchant_key:
        raise ValueError("Payfast merchant credentials are not configured")
    name_parts = booking["parent"]["name"].strip().split()
    first = name_parts[0]
    last = " ".join(name_parts[1:]) or "-"
    fields: dict[str, str] = {
        "merchant_id": settings.payfast_merchant_id,
        "merchant_key": settings.payfast_merchant_key,
        "return_url": f"{settings.app_base_url}/payment/success",
        "cancel_url": f"{settings.app_base_url}/payment/cancel",
        "notify_url": f"{settings.app_base_url}/api/payments/payfast/itn",
        "name_first": first,
        "name_last": last,
        "email_address": booking["parent"]["email"],
        "cell_number": booking["parent"]["phone"],
        "m_payment_id": booking["id"],
        "amount": f'{booking["total"]:.2f}',
        "item_name": f'Dragons swimming lessons - {booking["swimmer"]["name"]}',
    }
    fields["signature"] = signature(fields, settings.payfast_passphrase)
    return fields


def verify_notification_signature(data: Mapping[str, object], passphrase: str) -> bool:
    provided = str(data.get("signature", ""))
    return bool(provided) and provided == signature(data, passphrase)


def valid_payfast_ip(ip_text: str | None) -> bool:
    if not ip_text:
        return False
    clean = ip_text.removeprefix("::ffff:")
    try:
        addr = ipaddress.ip_address(clean)
    except ValueError:
        return False
    if any(addr in network for network in PAYFAST_NETWORKS):
        return True
    for host in PAYFAST_HOSTS:
        try:
            for info in socket.getaddrinfo(host, 443):
                if info[4][0] == clean:
                    return True
        except OSError:
            continue
    return False


def validate_with_payfast(data: Mapping[str, object], validate_url: str) -> bool:
    payload = [(key, str(value)) for key, value in data.items() if key != "signature"]
    encoded = urllib.parse.urlencode(payload).encode("utf-8")
    request = urllib.request.Request(
        validate_url,
        data=encoded,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            return response.read().decode("utf-8").strip() == "VALID"
    except OSError:
        return False
