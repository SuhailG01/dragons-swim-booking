from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def load_dotenv(path: Path | None = None) -> None:
    path = path or Path(__file__).resolve().parents[1] / ".env"
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip())


@dataclass(frozen=True)
class Settings:
    app_base_url: str
    admin_key: str
    payment_mode: str
    payfast_merchant_id: str
    payfast_merchant_key: str
    payfast_passphrase: str
    payfast_process_url: str
    payfast_validate_url: str

    @classmethod
    def from_env(cls) -> "Settings":
        load_dotenv()
        mode = os.getenv("PAYMENT_MODE", "demo").lower().strip()
        if mode not in {"demo", "sandbox", "live"}:
            mode = "demo"
        sandbox = mode == "sandbox"
        return cls(
            app_base_url=os.getenv("APP_BASE_URL", "http://localhost:8000").rstrip("/"),
            admin_key=os.getenv("ADMIN_KEY", "change-this-before-deploying"),
            payment_mode=mode,
            payfast_merchant_id=os.getenv("PAYFAST_MERCHANT_ID", "").strip(),
            payfast_merchant_key=os.getenv("PAYFAST_MERCHANT_KEY", "").strip(),
            payfast_passphrase=os.getenv("PAYFAST_PASSPHRASE", "").strip(),
            payfast_process_url=os.getenv("PAYFAST_PROCESS_URL", "").strip()
            or ("https://sandbox.payfast.co.za/eng/process" if sandbox else "https://www.payfast.co.za/eng/process"),
            payfast_validate_url=os.getenv("PAYFAST_VALIDATE_URL", "").strip()
            or ("https://sandbox.payfast.co.za/eng/query/validate" if sandbox else "https://www.payfast.co.za/eng/query/validate"),
        )
