from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path
from uuid import uuid4

DB_PATH = Path(__file__).resolve().parents[1] / "data" / "dragons.db"


@contextmanager
def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with connect() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS lessons (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                level TEXT NOT NULL,
                coach TEXT NOT NULL,
                start TEXT NOT NULL,
                duration INTEGER NOT NULL,
                capacity INTEGER NOT NULL,
                price REAL NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS bookings (
                id TEXT PRIMARY KEY,
                parent_name TEXT NOT NULL,
                parent_email TEXT NOT NULL,
                parent_phone TEXT NOT NULL,
                swimmer_name TEXT NOT NULL,
                swimmer_age INTEGER NOT NULL,
                swimmer_level TEXT NOT NULL,
                lesson_ids TEXT NOT NULL,
                total REAL NOT NULL,
                status TEXT NOT NULL,
                pf_payment_id TEXT,
                created_at TEXT NOT NULL,
                paid_at TEXT
            );
            """
        )
        count = conn.execute("SELECT COUNT(*) FROM lessons").fetchone()[0]
        if count == 0:
            seed_lessons(conn)


def seed_lessons(conn: sqlite3.Connection) -> None:
    now = datetime.now().replace(second=0, microsecond=0)
    end = now + timedelta(days=100)
    coaches = ["Coach Mia", "Coach Jordan", "Coach Alex"]
    levels = ["Beginner", "Intermediate", "Advanced"]
    prices = {"Beginner": 180.0, "Intermediate": 195.0, "Advanced": 210.0}
    day = now
    rows = []
    while day <= end:
        # Tuesday, Thursday, Saturday
        if day.weekday() in {1, 3, 5}:
            for i, level in enumerate(levels):
                start = day.replace(hour=15 + i, minute=30 if i % 2 == 0 else 45)
                rows.append(
                    (
                        str(uuid4()),
                        f"{level} swim session",
                        level,
                        coaches[i],
                        start.isoformat(),
                        45,
                        7 if level == "Beginner" else 6,
                        prices[level],
                        datetime.now().isoformat(),
                    )
                )
        day += timedelta(days=1)
    conn.executemany(
        "INSERT INTO lessons VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", rows
    )


def _lesson_view(conn: sqlite3.Connection, row: sqlite3.Row) -> dict:
    lesson = dict(row)
    reservations = 0
    for booking in conn.execute(
        "SELECT lesson_ids FROM bookings WHERE status IN ('pending','paid')"
    ).fetchall():
        if lesson["id"] in json.loads(booking["lesson_ids"]):
            reservations += 1
    lesson["spots_left"] = max(0, lesson["capacity"] - reservations)
    return lesson


def list_lessons(month: str | None = None) -> list[dict]:
    with connect() as conn:
        if month:
            rows = conn.execute(
                "SELECT * FROM lessons WHERE substr(start,1,7)=? ORDER BY start", (month,)
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM lessons ORDER BY start").fetchall()
        return [_lesson_view(conn, row) for row in rows]


def get_lesson(lesson_id: str) -> dict | None:
    with connect() as conn:
        row = conn.execute("SELECT * FROM lessons WHERE id=?", (lesson_id,)).fetchone()
        return _lesson_view(conn, row) if row else None


def create_booking(payload: dict) -> dict:
    lesson_ids = list(dict.fromkeys(payload["lesson_ids"]))
    if not lesson_ids:
        raise ValueError("Select at least one lesson")
    lessons = [get_lesson(lesson_id) for lesson_id in lesson_ids]
    if any(lesson is None for lesson in lessons):
        raise ValueError("One or more lessons no longer exist")
    if any(lesson["spots_left"] < 1 for lesson in lessons):
        raise ValueError("One of your selected lessons is now full")
    total = round(sum(lesson["price"] for lesson in lessons), 2)
    booking_id = str(uuid4())
    created_at = datetime.now().isoformat()
    with connect() as conn:
        conn.execute(
            """
            INSERT INTO bookings (
                id,parent_name,parent_email,parent_phone,swimmer_name,swimmer_age,
                swimmer_level,lesson_ids,total,status,pf_payment_id,created_at,paid_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NULL, ?, NULL)
            """,
            (
                booking_id,
                payload["parent"]["name"],
                str(payload["parent"]["email"]),
                payload["parent"]["phone"],
                payload["swimmer"]["name"],
                payload["swimmer"]["age"],
                payload["swimmer"]["level"],
                json.dumps(lesson_ids),
                total,
                created_at,
            ),
        )
    return get_booking(booking_id)


def _booking_view(row: sqlite3.Row) -> dict:
    return {
        "id": row["id"],
        "parent": {"name": row["parent_name"], "email": row["parent_email"], "phone": row["parent_phone"]},
        "swimmer": {"name": row["swimmer_name"], "age": row["swimmer_age"], "level": row["swimmer_level"]},
        "lesson_ids": json.loads(row["lesson_ids"]),
        "total": row["total"],
        "status": row["status"],
        "pf_payment_id": row["pf_payment_id"],
        "created_at": row["created_at"],
        "paid_at": row["paid_at"],
    }


def get_booking(booking_id: str) -> dict | None:
    with connect() as conn:
        row = conn.execute("SELECT * FROM bookings WHERE id=?", (booking_id,)).fetchone()
        return _booking_view(row) if row else None


def bookings_by_email(email: str) -> list[dict]:
    with connect() as conn:
        rows = conn.execute(
            "SELECT * FROM bookings WHERE lower(parent_email)=lower(?) ORDER BY created_at DESC",
            (email,),
        ).fetchall()
        return [_booking_view(row) for row in rows]


def mark_paid(booking_id: str, pf_payment_id: str = "DEMO") -> dict:
    with connect() as conn:
        cur = conn.execute(
            "UPDATE bookings SET status='paid', paid_at=?, pf_payment_id=? WHERE id=?",
            (datetime.now().isoformat(), pf_payment_id, booking_id),
        )
        if cur.rowcount == 0:
            raise ValueError("Booking not found")
    return get_booking(booking_id)


def add_lesson(payload: dict) -> dict:
    lesson_id = str(uuid4())
    start = datetime.fromisoformat(payload["start"]).isoformat()
    with connect() as conn:
        conn.execute(
            "INSERT INTO lessons VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                lesson_id,
                payload["title"], payload["level"], payload["coach"], start,
                payload["duration"], payload["capacity"], payload["price"], datetime.now().isoformat()
            ),
        )
    return get_lesson(lesson_id)


def admin_summary() -> dict:
    lessons = list_lessons()
    now = datetime.now().isoformat()
    with connect() as conn:
        rows = conn.execute("SELECT * FROM bookings ORDER BY created_at DESC").fetchall()
        bookings = [_booking_view(row) for row in rows]
    paid = [b for b in bookings if b["status"] == "paid"]
    active = [b for b in bookings if b["status"] in {"pending", "paid"}]
    return {
        "metrics": {
            "total_bookings": len(bookings),
            "paid_revenue": round(sum(b["total"] for b in paid), 2),
            "upcoming_lessons": sum(1 for lesson in lessons if lesson["start"] > now),
            "reserved_seats": sum(len(b["lesson_ids"]) for b in active),
        },
        "recent_bookings": bookings[:10],
        "upcoming": [lesson for lesson in lessons if lesson["start"] > now][:20],
    }


def reset_database(path: Path | None = None) -> None:
    global DB_PATH
    if path is not None:
        DB_PATH = path
    if DB_PATH.exists():
        DB_PATH.unlink()
    init_db()
