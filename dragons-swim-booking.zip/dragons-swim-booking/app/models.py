from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, EmailStr, Field

Level = Literal["Beginner", "Intermediate", "Advanced"]


class ParentDetails(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: EmailStr
    phone: str = Field(min_length=7, max_length=30)


class SwimmerDetails(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    age: int = Field(ge=2, le=99)
    level: Level


class BookingCreate(BaseModel):
    parent: ParentDetails
    swimmer: SwimmerDetails
    lesson_ids: list[str] = Field(min_length=1, max_length=31)


class LessonCreate(BaseModel):
    title: str = Field(min_length=2, max_length=100)
    level: Level
    coach: str = Field(min_length=2, max_length=100)
    start: str
    duration: int = Field(ge=15, le=180)
    capacity: int = Field(ge=1, le=50)
    price: float = Field(ge=5, le=10000)
