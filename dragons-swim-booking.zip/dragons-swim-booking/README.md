# 🐉 Dragons Swimming Club — Booking & Payments App

A mobile-first full-stack booking platform for **Dragons Swimming Club**. Parents can browse monthly swimming lessons, reserve multiple sessions, pay the club, and return to view their bookings. The school gets an admin dashboard for bookings, paid revenue, lesson capacity and schedule management.

> Club reference: https://www.facebook.com/DragonsSwimming/
>
> The Dragons Swimming Club Facebook page supplied for this project does not expose its operating details reliably to automated public access, so coaches, lesson prices, times and the included logo are **demo placeholders**. Replace them with the club's approved information before production use.

![Dragons app preview](docs/dragons-app-preview.png)

## The user flow

**Choose month → filter by level → select lessons → add swimmer details → reserve → pay → track booking.**

## Features

### Parent experience
- Mobile-first responsive interface
- Browse lessons by month
- Beginner / Intermediate / Advanced filters
- Remaining-capacity display
- Select multiple sessions for the month
- Parent + swimmer checkout form
- Server-calculated totals
- Demo checkout for GitHub reviewers
- Payfast sandbox/live support
- Booking history by parent email
- Paid / pending booking states

### School admin
- Admin-key protected dashboard
- Booking count
- Paid revenue
- Reserved seats
- Upcoming lesson count
- Recent booking feed
- Live lesson capacity
- Add new lessons

### Engineering / security
- FastAPI backend
- SQLite persistence
- Pydantic validation
- Vanilla JavaScript SPA — no frontend build step
- Server-side price and capacity validation
- Payfast signature generation
- Payfast ITN signature validation
- Payfast source-IP validation
- Amount matching and Payfast validation callback
- Secrets stored in `.env`
- Automated tests
- GitHub Actions CI

## Stack

| Layer | Technology |
| --- | --- |
| Frontend | HTML5, modern CSS, vanilla JavaScript |
| Backend | Python, FastAPI |
| Database | SQLite |
| Validation | Pydantic |
| Payments | Payfast custom integration pattern |
| Tests | Pytest |
| CI | GitHub Actions |

## Quick start

### 1. Clone

```bash
git clone https://github.com/YOUR_USERNAME/dragons-swim-booking.git
cd dragons-swim-booking
```

### 2. Create a virtual environment

Windows PowerShell:

```powershell
py -3.12 -m venv .venv
.venv\Scripts\Activate.ps1
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install

```bash
pip install -r requirements.txt
```

### 4. Configure

Windows:

```powershell
Copy-Item .env.example .env
```

macOS/Linux:

```bash
cp .env.example .env
```

The default mode is safe for a portfolio demo:

```env
PAYMENT_MODE=demo
```

### 5. Run

```bash
uvicorn app.main:app --reload
```

Open:

```text
http://localhost:8000
```

## Demo the full booking journey

1. Open **Book**.
2. Add several swimming lessons.
3. Click **Continue**.
4. Enter a parent and swimmer.
5. Click **Reserve & continue to payment**.
6. In demo mode, click **Complete demo payment**.
7. Open **My lessons** to see the paid booking.

No real money is charged in demo mode.

## Admin dashboard

Set this in `.env`:

```env
ADMIN_KEY=replace-with-a-long-random-secret
```

Open `#/admin` and enter the key.

For a real multi-staff deployment, replace the single admin key with proper role-based login.

## Payfast integration

The app starts with demo payments. To test Payfast:

```env
PAYMENT_MODE=sandbox
PAYFAST_MERCHANT_ID=your_sandbox_merchant_id
PAYFAST_MERCHANT_KEY=your_sandbox_merchant_key
PAYFAST_PASSPHRASE=your_sandbox_passphrase
APP_BASE_URL=https://your-public-test-domain.example
```

The server sends the parent to Payfast's hosted checkout, so card/banking details are not entered into this application. The ITN endpoint verifies the signature, expected amount, source IP/domain and Payfast validation response before marking the booking paid.

For local ITN testing, expose the app through a temporary public HTTPS URL because Payfast cannot post payment notifications to `localhost`.

## Tests

```bash
pip install -r requirements-dev.txt
pytest -q
```

## Repository structure

```text
dragons-swim-booking/
├── app/
│   ├── config.py
│   ├── db.py
│   ├── main.py
│   ├── models.py
│   └── payfast.py
├── static/
│   ├── app.js
│   ├── styles.css
│   ├── dragon-mark.svg
│   └── index.html
├── tests/
├── docs/
├── .github/workflows/ci.yml
├── .env.example
├── requirements.txt
└── README.md
```

## Why this is portfolio-worthy

This project is not just a booking UI. It demonstrates:

1. **Business workflow design** — the user can book an entire month in one checkout.
2. **Backend authority** — the browser cannot decide prices or fake available capacity.
3. **Payment boundaries** — sensitive card data stays with the payment provider.
4. **Webhook verification** — a browser redirect alone does not mark a booking as paid.
5. **Persistence and reporting** — bookings feed directly into the school dashboard.
6. **Responsive product design** — the parent flow is optimized for phones first.
7. **Clear production roadmap** — the demo is easy to run while the architecture can grow.

## Before real parents use it

- Replace demo schedule, coaches, prices and branding with club-approved information.
- Move SQLite to PostgreSQL for a multi-instance cloud deployment.
- Add parent authentication/passwordless login and saved swimmer profiles; email-only booking lookup is intentionally demo-grade.
- Add POPIA-aligned privacy notice, consent and data retention rules.
- Add the club's cancellation/refund/make-up policy.
- Configure the club's Payfast account and complete sandbox testing.
- Use HTTPS in production.
- Add email/WhatsApp confirmations and reminders.
- Add backups, monitoring and audit logs.

## Roadmap

- Multiple swimmers per parent
- Coach portal
- Attendance register
- Waiting lists
- Make-up lesson credits
- Automated WhatsApp reminders
- Email receipts
- Recurring monthly plans
- PostgreSQL
- PWA push notifications
- Cloud deployment

## Brand note

The dragon/water icon included in this repository is an original placeholder created for this software project. Replace it with Dragons Swimming Club's approved official brand assets before a public production launch.

## License

MIT
