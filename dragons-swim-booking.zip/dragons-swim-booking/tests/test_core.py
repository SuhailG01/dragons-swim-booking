from pathlib import Path

from app import db
from app.config import Settings
from app.payfast import build_payment_fields, pf_encode, signature


def setup_function():
    db.reset_database(Path("/tmp/dragons_test.db"))


def test_seeded_lessons_exist():
    assert len(db.list_lessons()) > 10


def test_booking_total_is_server_calculated():
    lesson = db.list_lessons()[0]
    booking = db.create_booking(
        {
            "parent": {"name": "Parent Test", "email": "parent@example.com", "phone": "0712345678"},
            "swimmer": {"name": "Swimmer Test", "age": 8, "level": lesson["level"]},
            "lesson_ids": [lesson["id"]],
        }
    )
    assert booking["total"] == lesson["price"]
    assert booking["status"] == "pending"


def test_paid_booking_reduces_capacity():
    lesson = db.list_lessons()[0]
    before = lesson["spots_left"]
    booking = db.create_booking(
        {
            "parent": {"name": "Parent Test", "email": "parent@example.com", "phone": "0712345678"},
            "swimmer": {"name": "Swimmer Test", "age": 8, "level": lesson["level"]},
            "lesson_ids": [lesson["id"]],
        }
    )
    db.mark_paid(booking["id"])
    after = db.get_lesson(lesson["id"])["spots_left"]
    assert after == before - 1


def test_payfast_encoding_and_signature():
    assert pf_encode("Dragon Swim") == "Dragon+Swim"
    assert signature({"merchant_id": "1", "amount": "180.00"}, "secret") == signature(
        {"merchant_id": "1", "amount": "180.00"}, "secret"
    )


def test_payment_fields_are_server_signed():
    settings = Settings(
        app_base_url="https://example.com",
        admin_key="x",
        payment_mode="sandbox",
        payfast_merchant_id="10000100",
        payfast_merchant_key="test",
        payfast_passphrase="secret",
        payfast_process_url="https://sandbox.payfast.co.za/eng/process",
        payfast_validate_url="https://sandbox.payfast.co.za/eng/query/validate",
    )
    booking = {
        "id": "booking-1",
        "total": 180.0,
        "parent": {"name": "Jane Parent", "email": "jane@example.com", "phone": "0712345678"},
        "swimmer": {"name": "Sam"},
    }
    fields = build_payment_fields(booking, settings)
    assert fields["amount"] == "180.00"
    assert fields["signature"]
    assert fields["merchant_key"] == "test"
